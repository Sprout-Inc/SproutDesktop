/* 
Copyright SproutInc 2022
Some code below by @Ancoder
JQuery should be installed from ancoder.ml or any other cdn
*/
console.log('Copyright Sprout 2022')

var checkedValue

$(document).ready(function () {
    /* Defines Functions */
    function ConnectWebsocket() {
        return new WebSocket("wss://SproutServer.sproutinc.repl.co")
    }
    /* Starts Client */
    var ws = null
    $("#btn-login").on("click", () => {
        checkedValue = JSON.parse($("input:radio[name='room']:checked").val())
        username = $("#value-username")
        if (checkedValue < 1 || checkedValue > 3) {
            console.log("Invalid Room")
            $("#message").text("Invalid room please try again.")
        } else {
            ws = ConnectWebsocket()
            ws.onerror = () => {
                $("#message").text("Sorry the Sprout server is currently down please try again later.")
            }
            ws.onopen = () => {
                ws.onclose = () => {
                    $("#login-body").show()
                    $("#message-body").hide()
                    $("#message").text("Disconnected due to unknown reason.")
                }
                ws.onmessage = ( data ) => {
                    msg = JSON.parse(data.data)
                    if ( msg["message"] == 101 ) {
                        $("#message").text("That username is blacklisted please try another one.")
                    } else if (msg["message"] == 404) {
                        $("#message").text("Invalid room please try again.")
                    } else if (msg["message"] == 200) {
                        console.log("Connection was made rewriting onmessage")
                        $("#message-body").show()
                        $("#login-body").hide()
                        /* OnMessage */
                        ws.onmessage = ( data ) => {
                            template = ""

                            document.getElementById("message-body").getElementsByClassName("container")[0].insertAdjacentHTML("beforeend", `${data.data}<br />`)
                        }
                        $("#btn-send").on("click", () => {
                            if ( ws.readyState == 1 ) {
                                ws.send($("#send-message").val())
                            }
                        })
                    }
                }
                ws.send(JSON.stringify({"username": username.val(), "room": JSON.parse(checkedValue)}))
                console.log("Client initiated!")
            }
        }
    })
})


